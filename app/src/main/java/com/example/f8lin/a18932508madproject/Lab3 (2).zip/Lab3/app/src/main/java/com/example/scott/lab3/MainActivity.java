package com.example.scott.lab3;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static final int PICK_CONTACT = 1;
    private String contact_number = null;

    Button selectButton = null;
    Button sendButton = null;
    TextView numView = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        selectButton = (Button) findViewById(R.id.selectButton);
        sendButton = (Button) findViewById(R.id.sendButton);
        numView = (TextView) findViewById(R.id.phoneTV);

        sendButton.setEnabled(false);

        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI);
                intent.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
                startActivityForResult(intent, PICK_CONTACT);
            }
        });

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(MainActivity.this, MessageActivity.class);
                myIntent.putExtra("contact_num", contact_number);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PICK_CONTACT && resultCode == RESULT_OK) {
                Uri contactUri = data.getData();
                String[] projection = new String[]{ContactsContract.CommonDataKinds.Phone.NUMBER};
                Cursor cursor = getContentResolver().query(contactUri, projection,null, null, null);
            // If the cursor returned is valid, get the phone contact_number
                 if (cursor != null && cursor.moveToFirst()) {
                     int numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                     contact_number = cursor.getString(numberIndex);
                     // Do something with the phone contact_number
                     Log.d("TEST",contact_number);
                     numView.setText(contact_number);
                     if(contact_number!=null && contact_number.length()>0){
                         sendButton.setEnabled(true);
                     }else{
                         sendButton.setEnabled(false);
                     }
                 }
    } }
}
